1. Launch windows application.
2. OS Interface Generator form appears.
3. 'Enter Key' has a drop down list where user can select or enterthe required key(eg.s7_M_C). This gets stored in 'PropertyKey'.
4. User gets to select  or enter the value for the selected key. This gets stored in propertyKey.
5.'Browse your Input File' allows user to browse the required source file(SCL or AWL files). 
  * When the user clicks button 'Browse File', it invokes BtnSelectFile_Click(). File Dialouge box opens and user can selct the source file.
  * The absolute path of the selected file gets stored in 'InputFileLocation'.
  * Source_FileExtractor object is created. 
  * GetNamePropertyValue function is created with input file location which returns the value to propertyName.
  * GetInputVarOutputVarcontent() is called with input file location and returns dictionary containing collection of input and output varaibles.
6. User can browse for the folder where his target output file is to be saved. 
  * When user clicks button 'Browse Folder', it invokes the SelectFolder_Click(). 
  * Folder Browse Dialouge is displayed  and user can select the folder to save the target output file. 
  * The folsder's path will be saved to 'OutputFileLocation'.
7.  A CheckBox is available, where user can select the ouput file format (JSON,XLS). By default JSON format is selected.
  * "Generate Data" Button checks whether the input file format is AWL or SCL. 
  * It also checks for the file format which is ticked. Corresponding to that, it creates property value Extractor object and calls FindPropertyKey() which returns a list of EDC objects.
  * FileWriter Obj is created.
  * This list will be passed as an argument to WriteCSV() or WriteJSON() accordingly.
  * If file name already exists, then a prompt appears where user can give new name.
